name = "Sartaj Singh"
SID = "22106054"
department = " Data Science "
CGPA = 9.9
print("Hey,", name, "Here!\nMy SID is", SID, "\nI am from", department, "department and my CGPA is", CGPA)