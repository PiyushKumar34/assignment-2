a="python is a case sensitive language"
print("length of string=",len(a))
print(a[::-1])
b=a[10:26:1]
print(b)
replaced=a.replace("a case sensitive","object oriented")
print(replaced)
print(a.index("a"))
print(a.replace(" ",""))